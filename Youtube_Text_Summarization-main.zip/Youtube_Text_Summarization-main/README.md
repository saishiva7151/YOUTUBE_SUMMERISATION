I removed the myenv folder due to high data. If you want the library list, you can check the requirements.txt file.
Also check the ".gitignore.txt" file.

# Youtube_Text_Summarization
